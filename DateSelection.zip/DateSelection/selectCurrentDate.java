import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class selectCurrentDate {

		public static void main(String[] args) throws InterruptedException {
			System.setProperty("webdriver.chrome.driver","E:\\Selenium\\Applications\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.manage().window().maximize();
			
			driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
			String src="IXE";
			String dest="PNQ";
			String reqCurrency="INR";
			
			//Select country
			driver.findElement(By.id("autosuggest")).sendKeys("IND");
			Thread.sleep(2000);
			List<WebElement> options=driver.findElements(By.cssSelector(".ui-menu-item"));

			for(WebElement option: options) {
				System.out.println(option.getText());
				if(option.getText().equalsIgnoreCase("India")) {
					option.click();
					break;
				}
			}
			
			WebElement currencyDropdown=driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
			Select setCurrencyDropdown=new Select(currencyDropdown);
			setCurrencyDropdown.selectByVisibleText(reqCurrency);
			
			//Select source and destination
			driver.findElement(By.cssSelector("input#ctl00_mainContent_ddl_originStation1_CTXT")).click();
			driver.findElement(By.xpath("//a[@value='"+src+"']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value='"+dest+"']")).click();
			Thread.sleep(2000);
			//setting current date
			
			driver.findElement(By.xpath("//div[@id='ui-datepicker-div']//tr[3]/td[@class=' ui-datepicker-week-end ui-datepicker-days-cell-over  ui-datepicker-today']")).click();
			
			Thread.sleep(3000);
			driver.quit();
		}

}

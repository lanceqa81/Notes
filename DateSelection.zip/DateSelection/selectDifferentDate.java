import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class selectDifferentDate {

	public static void main(String[] args) throws InterruptedException {
		String reqMonth="December 2022";
		String reqDate="27";
		System.setProperty("webdriver.chrome.driver","E:\\Selenium\\Applications\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		
		driver.get("https://www.makemytrip.com/");
		Thread.sleep(2000);
		driver.switchTo().frame("webklipper-publisher-widget-container-notification-frame");
		driver.findElement(By.xpath("//a[@id='webklipper-publisher-widget-container-notification-close-div']")).click();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//li[@class='makeFlex hrtlCenter font10 makeRelative lhUser userLoggedOut']")).click();
		driver.findElement(By.xpath("//label[@for='departure']/span")).click();
		//Selecting month 
		List<WebElement> months = driver.findElements(By.xpath("//div[@class='DayPicker-Months']/div/div[@class='DayPicker-Caption']/div"));
		int monthCount=months.size();
		
		for(int i=0;i<monthCount;i++) {
			String monthPicker=months.get(i).getText();
			System.out.println("Validating month: "+monthPicker);
			if(monthPicker.equalsIgnoreCase(reqMonth)) {
				System.out.println("Month matched with the required month");
				//Selecting day
				List<WebElement> dates=driver.findElements(By.xpath("//div[@class='datePickerContainer']//div[@class='DayPicker-Day']/div/p"));
				int count=dates.size();
//				System.out.println("size of dates: "+count);
				for(int j=0;j<count;j++) {
					WebElement datepicker=dates.get(j);
					String date=datepicker.getText();
					System.out.println("Date is: "+date );
					if(date.equalsIgnoreCase(reqDate)) {
						datepicker.click();
						break;
					}
				}
				i++;
			}else {
				System.out.println("Month did not match");
			}
			
		}
		driver.quit();
	}

}
